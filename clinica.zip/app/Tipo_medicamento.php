<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tipo_medicamento extends Model
{
    //
}
