<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Compra_implemento extends Model
{
    //
}
