<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Morbido extends Model
{

}
