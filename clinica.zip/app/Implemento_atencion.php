<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Implemento_atencion extends Model
{
    //
}
