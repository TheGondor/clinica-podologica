

<?php $__env->startSection('content'); ?>
<input type="hidden" id="id_paciente" name="id_paciente" value="<?php echo e($personales->id); ?>">
<div class="container">
    <div id="accordion">
        <div class="card">
          <div class="card-header" id="headingOne">
            <h5 class="mb-0">
              <button class="btn btn-link" data-toggle="collapse" data-target="#antecedentes_personales" aria-expanded="true" aria-controls="collapseOne">
                Antecedentes Personales
              </button>
            </h5>
          </div>
      
          <div id="antecedentes_personales" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
            <?php echo $__env->make('paciente.personales.datos',compact('personales'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
        <div class="card">
          <div class="card-header" id="headingTwo">
            <h5 class="mb-0">
              <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#antecedentes_morbidos" aria-expanded="false" aria-controls="collapseTwo">
                Antecedentes Morbidos
              </button>
            </h5>
          </div>
          <div id="antecedentes_morbidos" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
            <?php echo $__env->make('paciente.morbidos.datos',compact('morbido','fecha_morbido'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
        <div class="card">
          <div class="card-header" id="headingThree">
            <h5 class="mb-0">
              <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#examenes" aria-expanded="false" aria-controls="collapseThree">
                Examen Fisico General
              </button>
            </h5>
          </div>
          <div id="examenes" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
            <?php echo $__env->make('paciente.examen.datos', compact('examen', 'fecha_examen'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
        <div class="card">
          <div class="card-header" id="headingThree">
            <h5 class="mb-0">
              <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#pies" aria-expanded="false" aria-controls="collapseThree">
                Pies
              </button>
            </h5>
          </div>
          <div id="pies" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
            <?php echo $__env->make('paciente.examen.pies',compact('pie', 'fecha_pies'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
        <div class="card">
          <div class="card-header" id="headingThree">
            <h5 class="mb-0">
              <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#atenciones" id="boton_ver_atenciones" aria-expanded="false" aria-controls="collapseThree">
                Atenciones
              </button>
            </h5>
          </div>
          <div id="atenciones" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
            <?php echo $__env->make('paciente.atencion.datos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
        </div>
    </div>
</div>

  <?php echo $__env->make('paciente.personales.modal_editar', compact('personales','regiones','estados','actividades','comunas'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('paciente.morbidos.modal_editar', compact('morbido', 'fecha_morbido'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('paciente.morbidos.modal_habitos', compact('habitos'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('paciente.morbidos.modal_medicamentos', compact('medicamentos'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('paciente.morbidos.modal_enfermedades', compact('enfermedades'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('paciente.morbidos.modal_patologias', compact('patologias'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('paciente.morbidos.modal_protocolo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('paciente.examen.modal_editar', compact('examen', 'fecha_examen'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('paciente.atencion.modal_atencion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script type="text/javascript">
 
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\clinica\resources\views/paciente/paciente.blade.php ENDPATH**/ ?>