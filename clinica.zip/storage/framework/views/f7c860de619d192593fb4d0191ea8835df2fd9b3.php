<ol class="breadcrumb page-breadcrumb">
	<li class="breadcrumb-item"><a href="/administracion">Panel Administracion</a></li>
	<li class="breadcrumb-item">Protocolo</li>
	<li class="position-absolute pos-top pos-right d-none d-sm-block"><span class="js-get-date"></span></li>
</ol>
<div class="subheader">
	<h1 class="subheader-title">
		<i class='subheader-icon fal fa-exclamation-circle'></i>Protocolo Patologias
		<small>

		</small>
	</h1>
</div>
<div class="row">
	<div class="col-xl-12">
        <div id="panel-6" class="panel d-none">
			<div class="panel-hdr">
				<h2 id='tituloAccion'>
					Editar
				</h2>
				<div class="panel-toolbar">
					<button class="btn btn-panel" data-action="panel-collapse" data-toggle="tooltip" data-offset="0,10" data-original-title="Minimizar"></button>
				</div>
			</div>
			<div class="panel-container show">
				<div class="panel-content p-0">
					<form id="editar_protocolo">
                        <input type="hidden" name="metodo" value="Actualizar" id="metodo">
                        <input type="hidden" name="id_protocolo" value="0" id="id_protocolo">
                        <div class="panel-content">
						<div class="form-row">
                            <div class="col-md-12 col-sm-12">
                                <label for="nombre_paciente">Agrega Patologia</label>
                                <input type="text" list="protocolos" class="form-control" id="nombre_patologia" name="nombre_patologia" required>
                                <datalist id="protocolos">
                                        <?php if(isset($protocolos)): ?>
                                        <?php $__currentLoopData = $protocolos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($enf->id); ?>"><?php echo e($enf->nombre_protocolo); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                </datalist>
                            </div>
                            <div class="col-md-12 mb-3">
                                <label class="form-label" for="validationDefault01">Protocolo</label>
                                <div class="panel-content">
                                    <div class="js-summernote" id="summernote"></div>
                                </div>
                            </div>
						</div>
						<div class="panel-content border-faded border-left-0 border-right-0 border-bottom-0 d-flex flex-row">
							<button id='btnAccion' class="btn btn-primary ml-auto" type="submit">Actualizar</button>
                        </div>
                        </div>
					</form>
				</div>
			</div>
		</div>
		<div id="panel-1" class="panel">
			<div class="panel-hdr">
				<h2>
					Protocolos<span class="fw-300"><i>Lista</i></span>
				</h2>
				<div class="panel-toolbar">
					<a onclick='nuevo()' class='btn btn-sm btn-outline-success mr-2' title='Nuevo'><i class="fal fa-plus-square"></i> Nuevo</a>
					<button class="btn btn-panel" data-action="panel-collapse" data-toggle="tooltip" data-offset="0,10" data-original-title="Collapse"></button>
				</div>
			</div>
			<div class="panel-container show">
				<div class="panel-content">
					<!-- datatable start -->
					<table id="dt-basic-example" class="table table-bordered table-hover table-striped w-100">
						<thead>
							<tr>
                            <th>Nombre Patologia</th>
							<th>Accion</th>
							</tr>
						</thead>
						<tbody>
						</tbody>
						<tfoot>
							<th>Nombre Patologia</th>
							<th>Accion</th>
							</tr>
						</tfoot>
					</table>
					<!-- datatable end -->
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container d-none">
	<div class="row">
		<div id="lienzo_etapa" class="my-auto col-12"></div>
	</div>
</div>

<script>
	$(document).ready(function()
	{
        $('#summernote').summernote({
            callbacks: {
                onImageUpload: function(files) {
                // upload image to server and create imgNode...
                var fotos = foto(files);
                }
            },
            height: 300
        });
				// initialize datatable
				$('#dt-basic-example').DataTable({
					processing: true,
					serverSide: false,
					responsive: true,
					ajax:{
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						url: "../ver_protocolos",
                        type: 'POST',
					},
					columns:[
						{
						data: 'nombre_patologia',
						name: 'nombre_patologia'

                        },
						{
							data: 'accion',
							name: 'accion',
							className: 'text-center'
						}
					],
					drawCallback: function(settings) {
						var pagination = $(this).closest('.dataTables_wrapper').find('.dataTables_paginate');
						pagination.toggle(this.api().page.info().pages > 1);
					}
				});

                $(".active").removeClass('active');
				$("#menu_protocolos").addClass('active');


				$("#editar_protocolo").submit(function(e){
					e.preventDefault();
					if($("#metodo").val() == "Guardar")
					{
                        modal = cargando("Guardando Patologia", "Guardando...");
						var check = "true";
					}
					else{
						if($("#metodo").val()=="Actualizar"){
                            modal = cargando("Actualizando Patologia", "Actualizando...");
							var check = "true";
						}
						else{
							var check = "false";
						}
					}
					if(check == "true"){
						var formdata = new FormData(document.getElementById("editar_protocolo"));
                        formdata.append('_token',$('meta[name="csrf-token"]').attr('content'));
                        formdata.append('protocolo', $('#summernote').summernote("code"));
						if($("#metodo").val()=="Actualizar"){
							formdata.append('_method','PUT');
                            formdata.append('id_patologia', $("#id_protocolo").val());
						}
						else{
							formdata.append('_method','POST');
						}

						$.ajax({
							headers: {
								'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							},
							url: 'protocolo2',
							processData: false,
							contentType: false,
							type: 'POST',
							data : formdata,
							success: function(data){
						//console.log(respuesta.resultado);
						//console.log(respuesta.mensaje);
						if(data.estado=="true"){
                            modal.out();
							Swal.fire({
								type: 'success',
								title: data.mensaje
							});
							$('#dt-basic-example').DataTable().ajax.reload();
							var rowToScrollTo = document.getElementById('editar_protocolo');
							$("#panel-1").removeClass('panel-collapsed');
							$("#panel-6").addClass('d-none');
							document.documentElement.scrollTop = rowToScrollTo.offsetTop;
						}
						else{
                            modal.out();
							Swal.fire({
								type: 'error',
								title: 'Oops...',
								text: data.mensaje,
							})
						}
					},
					error: function(){
                        modal.out();
						Swal.fire({
							type: 'error',
							title: 'Oops...',
							text: "Error al actualizar los datos",
						})
					}
				})
					}

				});
			});

	function nuevo(){
		var selectedPanel = $("#panel-6").closest('.panel');
		selectedPanel.children('.panel-container').collapse('show')
		.on('show.bs.collapse', function() {
			selectedPanel.removeClass("panel-collapsed");
        });
        $("#tituloAccion").html('Nuevo');
		$("#btnAccion").html('Guardar');
		$("#metodo").val('Guardar');
        $("#nombre_patologia").val("");
        document.getElementById("nombre_patologia").disabled = false;
        $('#summernote').summernote('reset');
		$("#panel-6").removeClass('d-none');
	}
	function editar(id){
		$("#id_protocolo").val(id);
        modal = cargando("Cargando Patologia", "Cargando...");
		$("#metodo").val('Actualizar');
		$.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
			url: 'protocolo2/'+id,
            type: 'GET',
			processData: true,
			contentType: false,
			success: function(data){
			//console.log(respuesta.resultado);
			//console.log(respuesta.mensaje);
			if(data.estado=="true"){
                modal.out();
				$("#tituloAccion").html('Editar');
				$("#btnAccion").html('Actualizar');
				$("#nombre_patologia").val(data.protocolo['nombre_patologia']);
                $('#summernote').summernote('code',data.protocolo.protocolo);
                document.getElementById("nombre_patologia").disabled = true;
				$("#panel-6").removeClass('d-none');

				var selectedPanel = $("#panel-6").closest('.panel');
				selectedPanel.children('.panel-container').collapse('show')
				.on('show.bs.collapse', function() {
					selectedPanel.removeClass("panel-collapsed");
				});
				document.documentElement.scrollTop = 0;
			}
			else{
                modal.out();
				Swal.fire({
					type: 'error',
					title: 'Oops...',
					text: data.mensaje,
				})
			}
		},
		error: function(){
            modal.out();
			Swal.fire({
				type: 'error',
				title: 'Oops...',
				text: "Ocurrio un error al cargar los datos",
			});
		}
	    })
    }


	function eliminar(id){
		var swalWithBootstrapButtons = Swal.mixin({
			customClass: {
				confirmButton: "btn btn-primary",
				cancelButton: "btn btn-danger mr-2"
			},
			buttonsStyling: false
		});
		swalWithBootstrapButtons
		.fire({
			title: "Esta seguro?",
			text: "No se podran revertir los cambios!",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: "Si, eliminar!",
			cancelButtonText: "No, cancelar!",
			reverseButtons: true
		})
		.then(function(result) {
			if (result.value) {
                modal = cargando("Elimiando Patologia", "Elimiando...");
				var formdata = new FormData();
				formdata.append('_method','DELETE');
                formdata.append('id_patologia',id);
				$.ajax({
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					url: 'protocolo2',
					processData: false,
					contentType: false,
					type: 'POST',
					data : formdata,
					success: function(data){
			//console.log(respuesta.resultado);
			//console.log(respuesta.mensaje);
			if(data.estado=="true"){
                modal.out();
				swalWithBootstrapButtons.fire(
					"Eliminado!",
					data.mensaje,
					"success"
					);
				$('#dt-basic-example').DataTable().ajax.reload();
			}
			else{
                modal.out();
				Swal.fire({
					type: 'error',
					title: 'Oops...',
					text: data.mensaje,
				})
			}
		},
		error: function(){
            modal.out();
			swalWithBootstrapButtons.fire(
				"Error",
				"Ocurrio un error al intentar eliminar los datos",
				"error"
				);
			modal.out();
		}
	})

			} else if (
		// Read more about handling dismissals
		result.dismiss === Swal.DismissReason.cancel
		) {
				swalWithBootstrapButtons.fire(
					"Cancelado",
					"El paciente no fue eliminado",
					"error"
					);
			}
		});
	}

    function foto(file){
        if(file[0].type.match('image.*')){
            $("#lienzo_etapa").empty();
            img = new Image();
            img.onload = function(){
                if(this.width<=1920){
                    var ancho = this.width;
                    var alto = this.height;
                }
                else{
                    var ratio = this.width/1920;
                    var ancho = this.width/ratio;
                    var alto = this.height/ratio;
                }
                var canvasDiv3 = document.getElementById('lienzo_etapa');
                canvas3 = document.createElement('canvas');
                canvas3.setAttribute('width', ancho);
                canvas3.setAttribute('height', alto);
                canvas3.setAttribute('id', 'canvas3');
                canvasDiv3.appendChild(canvas3);
                if(typeof G_vmlCanvasManager != 'undefined') {
                    canvas3 = G_vmlCanvasManager.initElement(canvas);
                }
                context3 = canvas3.getContext("2d");
                context3.clearRect(0, 0, canvas3.width, canvas3.height);
                context3.drawImage(img,0,0,ancho,alto);
                var formdata = new FormData();
                formdata.append('img',canvas3.toDataURL("image/jpeg"));
                //console.log(canvas3.toDataURL("image/jpeg"));
                $.ajax({
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					url: 'upload_foto',
					processData: false,
					contentType: false,
					type: 'POST',
					data : formdata,
                    success: function(data){
                        //console.log(respuesta.resultado);
                        $img = $('<img>').attr({ src: data.url })
                        $('#summernote').summernote('insertNode', $img[0]);
                    },
                    error: function(){
                        swalWithBootstrapButtons.fire(
                            "Error",
                            "Ocurrio un error al intentar eliminar los datos",
                            "error"
                            );
                        modal.out();
                    }
                })
            };
            var URL = window.webkitURL || window.URL;
            img.src = URL.createObjectURL(file[0]);
        }
        else{
            Swal.fire({
                type: "error",
                title: "Oops...",
                text: "El archivo seleccionado no corresponde a una imagen"
              });
        }
    }
</script>

<?php /**PATH C:\laragon\www\clinica\resources\views/administracion/protocolo.blade.php ENDPATH**/ ?>